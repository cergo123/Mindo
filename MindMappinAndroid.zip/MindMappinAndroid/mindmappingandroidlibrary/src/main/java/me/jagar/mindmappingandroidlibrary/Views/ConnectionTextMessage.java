package me.jagar.mindmappingandroidlibrary.Views;

import android.content.Context;

public class ConnectionTextMessage extends android.support.v7.widget.AppCompatTextView {
    public ConnectionTextMessage(Context context) {
        super(context);
    }
}
