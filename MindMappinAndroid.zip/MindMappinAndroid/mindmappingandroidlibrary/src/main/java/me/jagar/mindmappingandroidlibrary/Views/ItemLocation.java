package me.jagar.mindmappingandroidlibrary.Views;

public class ItemLocation {
    public static int TOP = 0;
    public static int LEFT = 1;
    public static int RIGHT = 2;
    public static int BOTTOM = 3;
}
