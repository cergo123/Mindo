package me.jagar.mindmappingandroidlibrary.Listeners;

import me.jagar.mindmappingandroidlibrary.Views.Item;

public interface OnItemClicked {
    void OnClick(Item item);
}
